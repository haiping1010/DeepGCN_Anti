tem_neighbor = [[1, 2], [3, 4], [1, 2]] 
unique_tuples = set(tuple(item) for item in tem_neighbor)  
unique_lists = [list(item) for item in unique_tuples]  

print(unique_lists) 
