We only keep parts of the data here as example,due to the space limitation in github, please download the data yourself.
