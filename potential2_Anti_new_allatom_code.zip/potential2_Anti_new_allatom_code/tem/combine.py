import glob


file_arr=glob.glob("*_summary.txt")


fw=open("summary.txt",'w')

arr_all=[]
for name in file_arr:
    fr=open(name,'r')
    arr_tem=fr.readlines()
    arr_all=arr_all+arr_tem
    fr.close()

for line in arr_all:
    fw.write(line)

fw.close()
    
