
rm  summary.txt
for name in *_antibody.pdb
do

base=${name:0:4}	
echo $base
python  python_2_pp_stat.py  $base





done
