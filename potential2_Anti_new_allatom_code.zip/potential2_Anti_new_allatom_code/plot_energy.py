import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
np.random.seed(20180316)

#x = np.random.randn(4, 4)

dict_load=np.load('dict_energy.npy', allow_pickle=True).item()

energy=np.zeros((20,20))
seq=("ALA","ARG", "ASN", "ASP", "CYS", "GLU", "GLN", "GLY", "HIS", "ILE", "LEU", "LYS", "MET", "PHE", "PRO", "SER", "THR", "TRP", "TYR", "VAL")

for i in  range(len(seq)):
    for j in  range(len(seq)):
         res1=seq[i]
         res2=seq[j]
         energy[i,j]=round(dict_load[res1+'_'+res2],2)



f, (ax1) = plt.subplots(figsize=(6,6),nrows=1)

#sns.heatmap(x, annot=True, ax=ax1)
fig_name = 'heatplot.png'
yticklabels = seq
xticklabels = seq

#fig =sns.heatmap(energy,annot=True, ax=ax1, annot_kws={'size':9,'weight':'bold', 'color':'blue'})
fig =sns.heatmap(energy, xticklabels = xticklabels, yticklabels = yticklabels,annot=True, ax=ax1, annot_kws={'size':4,'weight':'bold', 'color':'blue'}, cmap='YlGnBu')

heat_fig = fig.get_figure()
heat_fig.savefig(fig_name, dpi = 400)



