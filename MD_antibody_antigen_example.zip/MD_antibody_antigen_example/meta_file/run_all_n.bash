cd ..

for folder in  A*_run  C*_run  F*_run     G*_run  N*_run  R*_run   V*_run
#for folder in  f8??-????_run
do

cd $folder


cp  -r    /home/zhanghaiping/work/pMD_run_redo_rdrp_add_meta/meta_file/prod.mdp      /home/zhanghaiping/work/pMD_run_redo_rdrp_add_meta/meta_file/gromac_meta.bash    /home/zhanghaiping/work/pMD_run_redo_rdrp_add_meta/meta_file/plumed.dat    .


nohup bash gromac_meta.bash &

sleep 20s


cd  ..

done



