
a=70
bb=$((a-70))

echo $bb
