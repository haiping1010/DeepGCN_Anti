
make_ndx_mpi -f npt2.gro -o tst.ndx  <<<"r 1-8
r 38-45
r 9-19
r 24-34
q
"
