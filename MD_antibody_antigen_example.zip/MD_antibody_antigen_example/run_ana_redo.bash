
echo 0 | gmx trjconv -s em.tpr -f  npt2.xtc -o  npt2_outx.xtc  -pbc  nojump -dt 100
echo -e "1\n0\n" | gmx trjconv -s em.tpr -f  npt2_outx.xtc -o  npt2_out.xtc  -pbc mol  -ur compact  -center 
#echo 0 | gmx trjconv -s em.tpr -f  npt2.xtc -o  npt2_out.xtc  -pbc nojump -ur compact -dt 100

echo 0 | gmx trjconv -s em.tpr -f  npt1.gro -o  npt2_outx.gro  -pbc  nojump -dt 100
echo -e "1\n0\n" | gmx trjconv -s em.tpr -f  npt2_outx.gro -o  npt2_out.gro  -pbc mol  -ur compact  -center

echo  -e "17\n18\n" | gmx rms -s  npt2_out.gro   -f  npt2_out.xtc -o  rms_out_lig.xvg  -tu ns  -n tst.ndx
echo  -e "1\n3\n" | gmx rms -s  npt2_out.gro   -f  npt2_out.xtc -o  rms_out_CA.xvg  -tu ns   -n tst.ndx

: '
echo 1 | gmx rmsf -s em.tpr -f  md_0_1_out.xtc -o  rmsf_out.xvg

echo -e "1\n13\n" | gmx hbond -s em.tpr -f  md_0_1_out.xtc -num  hbond.xvg

echo  12 | gmx  energy  -s em.tpr -f  md_0_1.edr -o   energy.xvg 


echo 1 | gmx rmsf -s em.tpr -f  md_0_1_out.xtc -o  rmsf_out_res.xvg -res

'

#gnuplot plot.p











